import type { Dirent, Stats } from '../types';
export declare function createDirentFromStats(name: string, stats: Stats): Dirent;
