'use strict'

const u = require('universalify').fromPromise
module.exports = {
  move: u(require('./move')),
  moveSync: require('./move-sync')
}
