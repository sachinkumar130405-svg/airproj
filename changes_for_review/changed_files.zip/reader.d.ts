import type Settings from '../settings';
export default class Reader {
    protected readonly _root: string;
    protected readonly _settings: Settings;
    constructor(_root: string, _settings: Settings);
}
