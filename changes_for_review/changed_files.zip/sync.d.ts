import type Settings from '../settings';
import type { Stats } from '../types';
export declare function read(path: string, settings: Settings): Stats;
